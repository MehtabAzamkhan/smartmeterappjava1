package com.example.myapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.Map;

public class settings extends AppCompatActivity {
    private static final String TAG = settings.class.getName();
    Button btnback,setTemp,setFeedInterval;
    EditText desiredTemp, feedInterval;
    private FirebaseDatabase mRootRef;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        FirebaseDatabase mRoot = FirebaseDatabase.getInstance();
        DatabaseReference mRootRef = mRoot.getReference();
        setContentView(R.layout.activity_settings);
        desiredTemp = findViewById(R.id.editTextNumber2);
        feedInterval = findViewById(R.id.editTextNumber3);
        btnback = findViewById(R.id.button3);
        setTemp = findViewById(R.id.button4);
        setFeedInterval = findViewById(R.id.button5);

        btnback.setOnClickListener(view -> {
            startActivity(new Intent(settings.this, dashboard.class));
        });

        setTemp.setOnClickListener(view -> {
            String value = desiredTemp.getText().toString();
            mRootRef.child("desiredT").setValue(value);

        });

        mRootRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                Map<String, Float> dataMap = (Map) snapshot.getValue();
                Number desiredTempature = (Number) dataMap.get("desiredT");
                Number feedInterval = (Number) dataMap.get("feedInterval");
                Log.d(TAG, "desiredTemperature: " + desiredTempature + " feedInterval " + feedInterval);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.d(TAG, "Error retrieving data");
            }
        });
    }
}